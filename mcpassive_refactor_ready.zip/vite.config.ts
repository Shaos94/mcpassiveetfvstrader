import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/mcpassiveetfvstrader/',
  server: {
    port: 5173,
  },
})
